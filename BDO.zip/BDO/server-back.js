const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const midtransClient = require('midtrans-client');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files from "public" directory

// Midtrans Server Key
const serverKey = 'Mid-server-cQRaChmHYB-nq34_JlG8pfKe'; // Replace with your Midtrans Server Key
const snap = new midtransClient.Snap({
    isProduction: true, // Set to true for production
    serverKey: serverKey,
});

// Route to Generate Snap Token
app.post('/create-snap-token', async (req, res) => {
    const { orderId, amount } = req.body;

    // Transaction details
    const parameters = {
        transaction_details: {
            order_id: orderId,
            gross_amount: amount,
        },
    };

    try {
        const transaction = await snap.createTransaction(parameters);
        res.json({ token: transaction.token });
    } catch (error) {
        console.error('Error creating Snap token:', error);
        res.status(500).json({ error: 'Failed to create Snap token' });
    }
});

// Start the Server
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
